#!/usr/bin/env python2.7

"""
Columbia's COMS W4111.001 Introduction to Databases
Example Webserver

To run locally:

    python server.py

Go to http://localhost:8111 in your browser.

A debugger such as "pdb" may be helpful for debugging.
Read about it online.
"""

import os
import datetime
from sqlalchemy import *
from sqlalchemy.pool import NullPool
from flask import Flask, request, render_template, g, redirect, Response
from decimal import *

tmpl_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'templates')
app = Flask(__name__, template_folder=tmpl_dir)
app.debug = True


#
# The following is a dummy URI that does not connect to a valid database. You will need to modify it to connect to your Part 2 database in order to use the data.
#
# XXX: The URI should be in the format of: 
#
#     postgresql://USER:PASSWORD@w4111a.eastus.cloudapp.azure.com/proj1part2
#
# For example, if you had username gravano and password foobar, then the following line would be:
#
#     DATABASEURI = "postgresql://gravano:foobar@w4111a.eastus.cloudapp.azure.com/proj1part2"
#
DATABASEURI = "postgresql://cl3390:0168@w4111a.eastus.cloudapp.azure.com/proj1part2"


#
# This line creates a database engine that knows how to connect to the URI above.
#
engine = create_engine(DATABASEURI)

#
# Example of running queries in your database
# Note that this will probably not work if you already have a table named 'test' in your database, containing meaningful data. This is only an example showing you how to run queries in your database using SQLAlchemy.
#
engine.execute("""CREATE TABLE IF NOT EXISTS test (
  id serial,
  name text
);""")
engine.execute("""INSERT INTO test(name) VALUES ('grace hopper'), ('alan turing'), ('ada lovelace');""")


@app.before_request
def before_request():
  """
  This function is run at the beginning of every web request 
  (every time you enter an address in the web browser).
  We use it to setup a database connection that can be used throughout the request.

  The variable g is globally accessible.
  """
  try:
    g.conn = engine.connect()
  except:
    print "uh oh, problem connecting to database"
    import traceback; traceback.print_exc()
    g.conn = None

@app.teardown_request
def teardown_request(exception):
  """
  At the end of the web request, this makes sure to close the database connection.
  If you don't, the database could run out of memory!
  """
  try:
    g.conn.close()
  except Exception as e:
    pass


#
# @app.route is a decorator around index() that means:
#   run index() whenever the user tries to access the "/" path using a GET request
#
# If you wanted the user to go to, for example, localhost:8111/foobar/ with POST or GET then you could use:
#
#       @app.route("/foobar/", methods=["POST", "GET"])
#
# PROTIP: (the trailing / in the path is important)
# 
# see for routing: http://flask.pocoo.org/docs/0.10/quickstart/#routing
# see for decorators: http://simeonfranklin.com/blog/2012/jul/1/python-decorators-in-12-steps/
#

# Global variable for loginID
global loginid
loginid = ""

global isbn
isbn = ""

@app.route('/')
def index():
  # get all the information of Buyers
  global loginid
  loginid = ""
  # get the bookName of all the books
  cursor = g.conn.execute('select bookName from Books_Provide ')
  results2 = []
  for n in cursor:
    n = str(n[0])
    results2.append(n)
  cursor.close()
  # get all the categories
  cursor = g.conn.execute('select cname from Categories')
  results3 = []
  for n in cursor:
    n = str(n[0])
    results3.append(n)
  cursor.close()
  return render_template('index.html', data2 = results2, cat = results3)


@app.route('/logged')
def logged():
  global loginid
  global isbn
  isbn = ""

  # get the bookName of all the books
  cursor = g.conn.execute('select bookName from Books_Provide ')
  results2 = []
  for n in cursor:
    n = str(n[0])
    results2.append(n)
  cursor.close()

  # get all the categories
  cursor = g.conn.execute('select cname from Categories')
  results3 = []
  for n in cursor:
    n = str(n[0])
    results3.append(n)
  cursor.close()

  # recommend books to the users
  cursor = g.conn.execute('select isbn from histories where loginID = %s order by history_date DESC', loginid)
  index = []
  for n in cursor:
	index.append(str(n[0]))
  cursor.close()
  print index
  
  cursor = g.conn.execute('select isbn from belong_to where isbn != %s AND cname = (select cname from belong_to where isbn = %s)', index[0], index[0])
  bookr = ""
  for n in cursor:
  	bookr = n[0]
  cursor.close()

  cursor = g.conn.execute('select B.bookName from Books_Provide B where B.isbn = %s', bookr)
  recommend = []
  for n in cursor:
  	recommend.append(n)
  cursor.close()
  print recommend

  return render_template('index_logged.html', user = loginid, books = results2, cat = results3, bookr = bookr)


# If both loginID and Password correct, link to index_logged, else ask for for inputs continously.
@app.route('/check', methods = ['POST'])
def check():
  global loginid
  # check whether the user exsit and the password correct
  loginID = request.form['loginID']
  password = request.form['passward']
  cursor = g.conn.execute('select loginID, passward from Users')
  results4 = []
  for n in cursor:
    l = n[0]
    p = n[1]
    results4.append([l, p])
  cursor.close()
  # judge the correctness of loginID and password
  if [loginID, password] in results4:
    loginid = loginID
    return redirect('logged')
  else:
    loginid = ""
    return render_template('log.html', error = "either user name or password is not correct.")
@app.route('/check', methods = ['GET'])

#
# This is an example of a different path.  You can see it at:
# 
#     localhost:8111/another
#
# Notice that the function name is another() rather than index()
# The functions for each app.route need to have different names
#
@app.route('/result', methods = ['POST'])
def result():
  global loginid
  global isbn
  bookName = request.form['books']
  category = request.form['categories']

  # error = ""

  # cursor = g.conn.execute('select isbn from belong_to where cname = %s', category)
  # check = []
  # for n in cursor:
  # 	check.append(str(n[0]))
  # cursor.close()
  # print check
  # print isbn
  # if isbn not in check:
  # 	return render_template('index.html', error = "the book is not in the category.")

  cursor = g.conn.execute('select * from Books_Provide where bookName = %s AND isbn in (select isbn from Belong_to where cname = %s)', bookName, category)
  results3 = []
  for n in cursor:
    results3.append(n)
  cursor.close()

  cursor = g.conn.execute('select isbn from Books_Provide where bookName = %s AND isbn in (select isbn from Belong_to where cname = %s)', bookName, category)
  isbn = []
  for n in cursor:
    isbn = str(n[0])
  cursor.close()

  cursor = g.conn.execute('select * from Review where isbn = %s', isbn)
  reviews = []
  for n in cursor:
  	reviews.append(n)
  cursor.close()

  return render_template('result.html', data = results3, user = loginid, reviews = reviews)
@app.route('/result', methods = ['GET'])
def result_get():
  return render_template('result_get.html')


@app.route('/result_logged', methods = ['POST'])
def result_logged():
  global loginid
  global isbn
  bookName = request.form['books']
  category = request.form['categories']
  
  cursor = g.conn.execute('select * from Books_Provide where bookName = %s AND isbn in (select isbn from Belong_to where cname = %s)', bookName, category)
  results3 = []
  for n in cursor:
    results3.append(n)
  cursor.close()

  cursor = g.conn.execute('select isbn from Books_Provide where bookName = %s AND isbn in (select isbn from Belong_to where cname = %s)', bookName, category)
  isbn = []
  for n in cursor:
    isbn = str(n[0])
  cursor.close()

  cursor = g.conn.execute('select * from Review where isbn = %s', isbn)
  reviews = []
  for n in cursor:
  	reviews.append(n)
  cursor.close()

  # insert the hostory of seraching books.
  g.conn.execute('insert into histories(loginID, history_date, isbn) values(%s, %s, %s)', loginid, datetime.datetime.now(), isbn)

  return render_template('result_logged.html', data = results3, user = loginid, reviews = reviews)
@app.route('/result_logged', methods = ['GET'])
def reuult_logged_get():
  return render_template('result_logged_get.html')



@app.route('/buy', methods = ['POST','GET'])
def buy():
  global loginid
  global isbn

  cursor = g.conn.execute('select bookName from Books_Provide where isbn = %s', isbn)
  for n in cursor:
    bookName = str(n[0])
  cursor.close()

  quantity = request.form['number']
  city = request.form['city']
  address = request.form['address']
  senddate = request.form['date']

  cursor = g.conn.execute('select max(orderid) from orders_make_send')
  for n in cursor:
    oid = n[0] + 1
  cursor.close()

  cursor = g.conn.execute('select loginid from Buyers')
  buyers = []
  for n in cursor:
    buyers.append(str(n[0]))
  cursor.close()
  print buyers

  cursor = g.conn.execute('select quantity, credit_cost from Books_Provide where isbn = %s', isbn)
  quantity_store=[]
  credit_cost=[]
  for n in cursor:
    quantity_store = n[0]
    credit_cost = n[1]
  cursor.close()
  print credit_cost, quantity_store

  cursor = g.conn.execute('select credit from users where loginID = %s', loginid)
  credit = []
  for n in cursor:
    credit = n[0]
  cursor.close()

  if (quantity_store - int(quantity)) < 0 :
    error = "quantity exeeds the maximum"
    return render_template("buy.html", user = loginid, isbn = isbn,  error = error)
  elif credit < credit_cost:
    error = "credit is insufficient"
    return render_template("buy.html", user = loginid, isbn = isbn, error = error)

  if loginid not in buyers:
   g.conn.execute('insert into Buyers(loginID) values(%s)', loginid)

  g.conn.execute('insert into orders_make_send(orderid, makedate, senddate, loginid, city, address) values(%s, %s, %s, %s, %s, %s)', oid, datetime.datetime.now(), senddate, loginid, city, address)
  g.conn.execute('insert into order_of(isbn,orderid) values(%s,%s)', isbn,oid)
  info = [oid, bookName, str(quantity), str(city), str(address), str(senddate)]
  
  q = quantity_store - int(quantity)
  g.conn.execute('UPDATE Books_Provide SET(quantity) = (%s) where isbn = %s', q, isbn)
  return render_template("orderinfo.html", user = loginid, isbn = isbn, info = info)
  

@app.route('/make_order', methods = ['POST','GET'])
def make_order():
  global loginid
  cursor = g.conn.execute('select credit from users where loginID = %s', loginid)
  credit = []
  for n in cursor:
    credit = n[0]
  cursor.close()
  return render_template('buy.html', user = loginid, credit = credit)


@app.route('/make_review', methods = ['POST','GET'])
def make_review():
  global loginid
  global isbn
  cursor = g.conn.execute('select isbn from Order_of O, orders_make_send M where O.orderID = M.orderID AND loginID = %s', loginid)
  booksb = []
  for n in cursor:
    booksb.append(str(n[0]))
  cursor.close()
  cursor = g.conn.execute('select isbn from Review where loginid = %s', loginid)
  booksr = []
  for n in cursor:
    booksr.append(str(n[0]))
  cursor.close()
  if ((isbn in booksb) and (isbn not in booksr)):
    return render_template('reviews.html', user = loginid)
  else:
    return redirect('logged')


@app.route('/save_review', methods = ['POST'])
def save_review():
  global loginid
  global isbn
  rate = request.form['rate']
  review = request.form['review']
  g.conn.execute('insert into Review(loginID, isbn, review_date, content, rate) values(%s, %s, %s, %s, %s)', 
    loginid, isbn, datetime.datetime.now(), review, rate)
  return render_template('review_success.html', user = isbn)


@app.route('/login')
def login():
    return render_template("log.html")


@app.route('/create', methods=['POST','GET'])
def create():
  return render_template('create.html')


@app.route('/new', methods=['POST','GET'])
def new():
  loginid = request.form['loginid']
  password =  request.form['password']
  firstname = request.form['firstname']
  lastname = request.form['lastname']
  email = request.form['email']
  phone = request.form['phone']

  cursor = g.conn.execute('select loginID from users')
  user_loginid = []
  for n in cursor:
    user_loginid.append(str(n[0]))
  cursor.close()
  print user_loginid

# Check non-and illegal value for input
  if loginid is u"" or None:
    error = 'loginid can not be None'
    return render_template('create.html', error = error)
  elif loginid in user_loginid:
    error = 'loginID already exists'
    return render_template('create.html', error = error)
  elif password is u"" or None:
    error = 'password can not be None'
    return render_template('create.html', error = error)
  elif lastname is u"" or None:
    error = 'lastname can not be None'
    return render_template('create.html', error = error)
  elif email is u"" or None:
    error = 'email can not be None'
    return render_template('create.html', error = error)
  elif phone is u"" or None or (len(phone) > 10):
    error = 'phonenumber can not be None or more than 10 digits'
  else:
    try:
     phone1 = int(phone)
    except ValueError:
      error = 'phonenumber can not be non-number'
    return render_template('create.html', error = error)

  g.conn.execute('INSERT INTO users(loginid, passward, firstname, lastname, email, credit, phonenumber) VALUES( %s, %s,%s, %s, %s, %s, %s) ', 
    loginid,password,firstname,lastname,email,0,phone)
  return render_template('success.html')


@app.route('/user_information', methods=['POST','GET'])
def records():
  global loginid

  cursor = g.conn.execute('select * from Provide_details where loginID = %s', loginid)
  results4 = []
  for n in cursor:
    results4.append(n)
  cursor.close()

  cursor = g.conn.execute('select * from orders_make_send o1, order_of o2, books_provide b where o1.orderid=o2.orderid AND o2.isbn = b.isbn AND loginID = %s', loginid)
  results5 = []
  for n in cursor:
    results5.append(n)
  cursor.close()
  print results5

  cursor = g.conn.execute('select credit from users where loginID = %s', loginid)
  credit = []
  for n in cursor:
    credit = n[0]
  cursor.close()
  print credit 

  return render_template('user_information.html', data = results4, user = loginid, data1=results5, credit=credit)


@app.route('/provide', methods=['POST','GET'])
def provide():
  global loginid
  return render_template('provide.html', user = loginid)


@app.route('/book', methods=['POST','GET'])
def book():
  global loginid
  isbn = request.form['isbn']
  title = request.form['bookname']
  author = request.form['author']
  cat = request.form['cat']
  price = request.form['price']
  quantity = request.form['quantity']

# Check non-and illegal value for input
  if isbn is u"" or None:
    error = 'isbn can not be None'
    return render_template('provide.html', user = loginid, error = error)
  elif title is u"" or None:
    error = 'title can not be None'
    return render_template('provide.html', user = loginid, error = error)
  elif author is u"" or None:
    error = 'author can not be None'
    return render_template('provide.html', user = loginid, error = error)
  elif price is u"" or None or (price < 0):
    error = 'price can not be None or smaller than 0'
    return render_template('provide.html', user = loginid, error = error)
  elif quantity is u"" or None or (int(quantity) < 1):
    error = 'quantity can not be None or less than 1'
    return render_template('provide.html', user = loginid, error = error)

  credit = price * int(quantity)


  cursor = g.conn.execute('select isbn from Books_Provide')
  pro_isbn = []
  for n in cursor:
    pro_isbn.append(str(n[0]))
  cursor.close()
  print pro_isbn

  cursor = g.conn.execute('select loginID from sellers')
  sellers = []
  for n in cursor:
    sellers.append(str(n[0]))
  cursor.close()
  print sellers

  cursor = g.conn.execute('select credit from users where loginID = %s', loginid)
  for n in cursor:
    credit_own = n[0]
  cursor.close()
  print credit_own

  cursor = g.conn.execute('select cname from Categories')
  cat_exist = []
  for n in cursor:
    cat_exist.append(str(n[0]))
  cursor.close()
  print cat_exist

  cursor = g.conn.execute('select price from Books_Provide where isbn = %s', isbn)
  for n in cursor:
    pro_price = n[0]
  cursor.close()
  print pro_price
  

  # Add user to sellers if he/she first provide a book
  if loginid not in sellers:
   g.conn.execute('INSERT INTO sellers(loginid) VALUES (%s)', loginid)

  # Add provide_details
  g.conn.execute('INSERT INTO Provide_details(isbn, bookname, author, price, credit_cost, quantity, provide_date,loginid) VALUES( %s, %s,%s, %s, %s, %s, %s, %s)', 
   isbn,title,author,price,credit,quantity,datetime.datetime.now(),loginid)
  
  # Update users credits.
  credit = Decimal(credit)
  credit_own = credit + credit_own
  g.conn.execute('UPDATE Users SET (credit) = (%s) where loginID = %s', credit_own, loginid)

  # Create a new book info if the book is not in inventory
  if isbn not in pro_isbn:
    g.conn.execute('INSERT INTO Books_Provide(isbn, bookname, author, price, credit_cost, quantity) VALUES( %s, %s,%s, %s, %s, %s)', 
      isbn,title,author,price,credit,quantity)
    g.conn.execute('INSERT INTO Belong_to(isbn,cname) VALUES (%s,%s)',isbn,cat)
  # If the book info exists, just add the quantity of the book
  else :
    # The input price should be the same with info in books_provide
    if Decimal(price) != Decimal(pro_price):
      error = 'price is not consistent'
      return render_template('provide.html', user = loginid, error = error)
      
    cursor = g.conn.execute('select quantity from Books_Provide where isbn = %s', isbn)
    for n in cursor:
      newquantity = n[0]
    cursor.close()
    q = newquantity + int(quantity)
    g.conn.execute('UPDATE Books_Provide SET(quantity)=( %s) where isbn = %s', q,isbn)

  # If a new category created, add it in to categories table and belong_to table.
  if cat not in cat_exist:
   g.conn.execute('INSERT INTO Categories(cname) VALUES (%s)',cat)
   
  return render_template('success1.html')


if __name__ == "__main__":
  import click

  @click.command()
  @click.option('--debug', is_flag=True)
  @click.option('--threaded', is_flag=True)
  @click.argument('HOST', default='0.0.0.0')
  @click.argument('PORT', default=8111, type=int)
  def run(debug, threaded, host, port):
    """
    This function handles command line parameters.
    Run the server using:

        python server.py

    Show the help text using:

        python server.py --help

    """

    HOST, PORT = host, port
    print "running on %s:%d" % (HOST, PORT)
    app.run(host=HOST, port=PORT, debug=debug, threaded=threaded)


  run()

# result1: 
# result2: 
# result3: all information of selected book
# result4: 
